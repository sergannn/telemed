import '../services/graphql_setup.dart';

const String kApiDomain = 'https://onlinedoctor.su/';

MyAppAuthLib graphqlAPI = MyAppAuthLib(kApiDomain);

bool printedLog = true;
bool printedResult = true;
