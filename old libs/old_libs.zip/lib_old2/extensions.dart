import 'dart:developer';

import 'package:doctorq/stores/doctors_store.dart';
import 'package:doctorq/stores/user_store.dart';
import 'package:flutter/material.dart';

import 'package:get_it/get_it.dart';

GetIt getIt = GetIt.instance;

extension BuildContextExt on BuildContext {
  static DoctorsStore storeDoctorsStore = getIt.get<DoctorsStore>();

  Map<dynamic, dynamic> get userData {
    UserStore storeUserStore = getIt.get<UserStore>();
    return storeUserStore.userData;
  }

  List get doctorsData {
    // DoctorsStore storeDoctorsStore = getIt.get<DoctorsStore>();

    return storeDoctorsStore.doctorsDataList;
  }

  void setSelectedDoctorByIndex(int index) {
    storeDoctorsStore
        .setSelectedDoctor(storeDoctorsStore.doctorsDataList[index]);
  }

  Map<dynamic, dynamic> get selectedDoctor {
    return storeDoctorsStore.selectedDoctor;
  }
}
