import 'package:flutter/material.dart';

class Constants{
 
  
  static String currency='\$';
  static Locale engLocal=const Locale('en');
  static Locale arLocal=const Locale('ar');
}