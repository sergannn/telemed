import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';


/*Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Permission.camera.request();
  await Permission.microphone.request(); // if you need microphone permission
  await Permission.storage.request();
  if (Platform.isAndroid) {
    await AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
  }
  runApp(MaterialApp(home: new SerView()));
}*/

class SerView extends StatefulWidget {
  final bool? doctor;
  String user;
  String doctorId;
  //SerView(bool doctor);

  SerView({Key? key, required this.doctorId, required this.user, this.doctor}) : super(key: key);
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<SerView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;
  InAppWebViewSettings options = InAppWebViewSettings(
      mediaPlaybackRequiresUserGesture: false,
      useHybridComposition: true,
      allowsInlineMediaPlayback: false,
      javaScriptCanOpenWindowsAutomatically: false,
      transparentBackground: true,
      allowBackgroundAudioPlaying: true);
  /* InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: true,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));
*/
  late PullToRefreshController pullToRefreshController;
  String url = "";
  double progress = 0;
  final urlController = TextEditingController();

  @override
  void initState() {
    super.initState();
     /*
    WidgetsFlutterBinding.ensureInitialized();

    Permission.camera.request();
    Permission.microphone.request(); // if you need microphone permission
    Permission.storage.request();
    if (Platform.isAndroid) {
      AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
    }*/
    /*Future.delayed(Duration(seconds: 15), () {
      print("tik");

      webViewController?.evaluateJavascript(source: "location.reload();");
    });*/
    pullToRefreshController = PullToRefreshController(
      options: PullToRefreshOptions(
        color: Colors.blue,
      ),
      onRefresh: () async {
        if (Platform.isAndroid) {
          webViewController?.reload();
        } else if (Platform.isIOS) {
          webViewController?.loadUrl(
              urlRequest: URLRequest(url: await webViewController?.getUrl()));
        }
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
   
    //Permission.camera.request();
    //Permission.microphone.request(); // if you need microphone permission
    //Permission.storage.request();
    if (Platform.isAndroid) {
      AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
    }
    return Scaffold(
        /*
        floatingActionButton:
            FloatingActionButton(onPressed: () {}, child: Text("stop")),*/
        // appBar: AppBar(title: Text("Official InAppWebView website")),
        body: SafeArea(
            child: Column(children: <Widget>[
      Expanded(
        child: Stack(
          children: [
            InAppWebView(
              // headlessWebView:true,
              key: webViewKey,
              initialUrlRequest: URLRequest(
                  //   url: WebUri("https://google.com")),
                  url: WebUri(widget.doctor == true
                      ? "https://webrtc20.onrender.com/tutorials/hello-world.html?id=500"
                      // jsonDecode(widget.user)['user_id']
                      : "https://webrtc20.onrender.com/tutorials/dial.html?id=500")), // widget.doctorId)),
              initialSettings: options,
              pullToRefreshController: pullToRefreshController,
              onWebViewCreated: (controller) {
                webViewController = controller;
              },
              onLoadStart: (controller, url) {
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              androidOnPermissionRequest:
                  (controller, origin, resources) async {
                return PermissionRequestResponse(
                    resources: resources,
                    action: PermissionRequestResponseAction.GRANT);
              },
              shouldOverrideUrlLoading: (controller, navigationAction) async {

                return NavigationActionPolicy.ALLOW;
              },
              onLoadStop: (controller, url) async {
                pullToRefreshController.endRefreshing();
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              onLoadError: (controller, url, code, message) {
                pullToRefreshController.endRefreshing();
              },
              onProgressChanged: (controller, progress) {
                if (progress == 100) {
                  pullToRefreshController.endRefreshing();
                }
                setState(() {
                  this.progress = progress / 100;
                  urlController.text = url;
                });
              },
              onUpdateVisitedHistory: (controller, url, androidIsReload) {
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              onConsoleMessage: (controller, consoleMessage) {
                if (consoleMessage.message == 'Session: ENDED') {
                  Navigator.pop(context);
                } 
              },
            ),
            progress < 1.0
                ? LinearProgressIndicator(value: progress)
                : Container(child: const Text("loading")),
          ],
        ),
      ),
      OverflowBar(
        alignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            child: const Icon(Icons.arrow_back),
            onPressed: () {
              webViewController?.goBack();
            },
          ),
          ElevatedButton(
            child: const Icon(Icons.arrow_forward),
            onPressed: () {
              webViewController?.goForward();
            },
          ),
          ElevatedButton(
            child: const Icon(Icons.refresh),
            onPressed: () {
              webViewController?.reload();
            },
          ),
        ],
      ),
    ])));
  }
}
