


import 'package:doctorq/constant/constants.dart';
import 'package:doctorq/models/doctor_model.dart';
import 'package:doctorq/stores/doctors_store.dart';
import 'package:doctorq/utils/utility.dart';


import 'package:get_it/get_it.dart';
import 'package:graphql/client.dart';
  
GetIt getIt = GetIt.instance;


Future<bool> getDoctors() async {

  printLog('Getting doctors');
  
  String getDoctors = '''
    query doctors {
      doctors(first: 108) {
        data {
            doctor_id: id
            specializations {
                name
            }
            doctorUser {
                user_id: id 
                username: full_name
                first_name
                last_name
                photo: profile_image
            }
        }
        paginatorInfo {
          total
          currentPage
          hasMorePages
        }
      }
    }
  ''';

  final QueryOptions options = QueryOptions(
    document: gql(getDoctors),
  );
  GraphQLClient graphqlClient = await graphqlAPI.noauthClient();
  debugPrintTransactionStart('query doctors');
  final QueryResult result = await graphqlClient.query(options);
  debugPrintTransactionEnd('query doctors');
  

  if (result.hasException) {
    printLog(result.exception.toString(), name: 'query doctors');
    // snackBar(context, message: result.exception.toString());
    return false;
  }
  
  final json = result.data!["doctors"]["data"];
  
  DoctorsStore storeDoctorsStore = getIt.get<DoctorsStore>();
  
  storeDoctorsStore.clearDoctorsData();

  json.forEach((doctor) { 
    DoctorModel doctorModel = DoctorModel.fromJson(doctor);
    storeDoctorsStore.addDoctorToDoctorsData(doctorModel.toJson());
  });
  
  return true;
}
