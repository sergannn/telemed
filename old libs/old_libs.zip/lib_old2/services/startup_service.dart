import 'dart:developer';

import 'package:doctorq/constant/constants.dart';
import 'package:doctorq/models/doctor_model.dart';
import 'package:doctorq/services/api_service.dart';
import 'package:doctorq/stores/doctors_store.dart';
import 'package:doctorq/utils/utility.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:graphql/client.dart';



Future<bool> getStartupData() async {
  printLog('Loading startup data');
  
  // logOut();

  await getDoctors();

  printLog('Doctors loaded');
  
  // final prefs = await SharedPreferences.getInstance();
  /*
  token = prefs.getString('token');
  user_id = prefs.getString("user_id");
  print('Token from SharedPreferences: $token, $user_id');*/
  // You can now use the token in your API calls
  //if( prefs.getString("user")== )
  // return prefs.getString("user") ?? '{"user_id":"-1"}';
  // return user_id ?? '-1';
  // return '{"user_id":"-1"}';
  printLog('Force Logged In State');
  return true;
}
