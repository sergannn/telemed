import 'dart:convert';

import 'package:doctorq/presentation/light_sign_in_blank_screen/light_sign_in_blank_screen.dart';
import 'package:doctorq/presentation/light_splash_screen/light_splash_screen.dart';
import 'package:doctorq/presentation/messages_detail_screen/messages_detail_screen.dart';
import 'package:doctorq/translations/codegen_loader.g.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/theme/theme_constants.dart';
import 'core/theme/theme_manager.dart';
import 'models/appointments_model.dart';
import '../core/utils/pub.dart';
import '../core/utils/image_constant.dart';
import 'package:doctorq/presentation/home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
  runApp(EasyLocalization(
      supportedLocales: [Locale("en"), Locale("ar")],
      path: "assets/translations",
      assetLoader: CodegenLoader(),
      fallbackLocale: Locale('en'),
      child: MyApp()));
}

ThemeManager themeManager = ThemeManager();

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
// TODO: implement initState

    themeManager.addListener(themeListener);

    super.initState();
  }

  @override
  void dispose() {
// TODO: implement dispose

    themeManager.removeListener(themeListener);

    super.dispose();
  }

  void themeListener() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Телемедицина',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: themeManager.themeMode,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      home: FutureBuilder<String>(
          future: getTokenFromPrefs(), // Call your future function here
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            if (snapshot.connectionState == ConnectionState.done &&
                jsonDecode(snapshot.data ?? '{}')['user_id'] != '-1') {
              getDoctors();
              // Once the future is done, display the text
              //return MessagesDetailScreen(),
              print("its a snapshot");
              print(snapshot.data);
              return Home(user: snapshot.data); // FloatingActionButton(
              //onPressed: null, child: Text(snapshot.data.toString()));
            } else {
              return LightSignInBlankScreen();
            }
          }), /*MessagesDetailScreen(
          appointment: AppointmentsModel( id:0,
              img: ImageConstant.doctor2,
              name: "Dr. Jane Cooper",
              contactMethodIcon: ImageConstant.reviews,
              status: 'Completed',
              time: '09:00 - 09:30 AM')),*/
      //LightSignInBlankScreen()
      //LightSplashScreen(),
    );
  }
}
