import 'package:doctorq/presentation/light_appointments_step_2_filled_screen/light_appointments_step_2_filled_screen.dart';
import 'package:doctorq/presentation/light_appointments_step_4_filled_screen/light_appointments_step_4_filled_screen.dart';
import 'package:doctorq/widgets/boxshadow.dart';
import '../../widgets/bkBtn.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/spacing.dart';
import 'package:doctorq/core/app_export.dart';
import 'package:doctorq/widgets/custom_button.dart';
import 'package:doctorq/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class LightAppointmentsStep3FilledScreen extends StatefulWidget {
  ContactMethods contactMethod;
  DateTime date;
  String time;
  LightAppointmentsStep3FilledScreen({
    required this.contactMethod,
    required this.date,
    required this.time,
  });

  @override
  _LightAppointmentsStep3FilledScreenState createState() =>
      _LightAppointmentsStep3FilledScreenState();
}

class _LightAppointmentsStep3FilledScreenState
    extends State<LightAppointmentsStep3FilledScreen> {
  List<String> ageRanges = [
    '10+',
    '20+',
    '30+',
    '40+',
    '50+',
  ];
  int selectedAge = 0;
  List<String> dropdownItemList = ["Male", "Female"];
  Object dropDownVal = 'Male';
  @override
  Widget build(BuildContext context) {
    print(widget.date);
    print("step 3<<<");
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              width: size.width,
              margin: getMargin(
                top: 20,
              ),
              child: Padding(
                padding: getPadding(
                  left: 20,
                  right: 20,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    BkBtn(),
                    HorizontalSpace(width: 20),
                    Text(
                      "Patient Details",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: getFontSize(
                          26,
                        ),
                        fontFamily: 'Source Sans Pro',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            VerticalSpace(height: 10),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      width: double.infinity,
                      margin: getMargin(
                        left: 24,
                        top: 24,
                        right: 24,
                      ),
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    2.00,
                                  ),
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: getPadding(
                                        left: 24,
                                        top: 1,
                                        right: 24,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 3,
                                            ),
                                            child: Text(
                                              "Full Name",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                color: isDark
                                                    ? Colors.white
                                                    : ColorConstant
                                                        .bluegray800A2,
                                                fontSize: getFontSize(
                                                  16,
                                                ),
                                                fontFamily: 'Source Sans Pro',
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              bottom: 5,
                                            ),
                                            child: Text(
                                              "*",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                color: ColorConstant.redA700A2,
                                                fontSize: getFontSize(
                                                  14,
                                                ),
                                                fontFamily: 'Source Sans Pro',
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                        boxShadow: isDark
                                            ? customDarkBoxShadow
                                            : customBoxShadow),
                                    child: CustomTextFormField(
                                      isDark: isDark,
                                      width: size.width,
                                      focusNode: FocusNode(),
                                      hintText: "Full name",
                                      margin: getMargin(
                                        top: 11,
                                      ),
                                      // variant: TextFormFieldVariant.OutlineBlueA400,
                                      fontStyle: TextFormFieldFontStyle
                                          .SourceSansProSemiBold16Gray900a2,
                                      padding:
                                          TextFormFieldPadding.PaddingAll18,
                                      alignment: Alignment.centerLeft,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: getPadding(
                          left: 48,
                          top: 24,
                          right: 48,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 5,
                              ),
                              child: Text(
                                "Select Your Age Range",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: isDark
                                      ? Colors.white
                                      : ColorConstant.bluegray800A2,
                                  fontSize: getFontSize(
                                    16,
                                  ),
                                  fontFamily: 'Source Sans Pro',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                bottom: 7,
                              ),
                              child: Text(
                                "*",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: ColorConstant.redA700A2,
                                  fontSize: getFontSize(
                                    14,
                                  ),
                                  fontFamily: 'Source Sans Pro',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    VerticalSpace(height: 12),
                    Container(
                      height: getVerticalSize(45),
                      child: ListView.separated(
                          padding: getPadding(
                            left: 24,
                            right: 24,
                          ),
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: true,
                          itemCount: ageRanges.length,
                          separatorBuilder: (context, index) =>
                              HorizontalSpace(width: 4),
                          itemBuilder: (context, index) {
                            return InkWell(
                              onTap: () {
                                setState(() {
                                  selectedAge = index;
                                });
                              },
                              child: Container(
                                padding: getPadding(
                                  left: 20,
                                  right: 20,
                                ),
                                decoration: BoxDecoration(
                                  color: selectedAge == index
                                      ? ColorConstant.blueA400
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      21.50,
                                    ),
                                  ),
                                  border: Border.all(
                                    color: ColorConstant.blueA400,
                                    width: getHorizontalSize(
                                      2.00,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      ageRanges[index],
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: selectedAge == index
                                            ? Colors.white
                                            : ColorConstant.blueA400,
                                        fontSize: getFontSize(
                                          18,
                                        ),
                                        fontFamily: 'Source Sans Pro',
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: getPadding(
                          left: 44,
                          top: 24,
                          right: 44,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 3,
                              ),
                              child: Text(
                                "Phone Number",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: isDark
                                      ? Colors.white
                                      : ColorConstant.bluegray800A2,
                                  fontSize: getFontSize(
                                    16,
                                  ),
                                  fontFamily: 'Source Sans Pro',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                bottom: 5,
                              ),
                              child: Text(
                                "*",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: ColorConstant.redA700A2,
                                  fontSize: getFontSize(
                                    14,
                                  ),
                                  fontFamily: 'Source Sans Pro',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          boxShadow:
                              isDark ? customDarkBoxShadow : customBoxShadow),
                      child: CustomTextFormField(
                        isDark: isDark,
                        width: size.width,
                        focusNode: FocusNode(),
                        hintText: "Phone Number",
                        padding: TextFormFieldPadding.PaddingAll18,
                        margin: getMargin(top: 11, left: 20, right: 20),
                        keyboardType: TextInputType.number,
                        // variant: TextFormFieldVariant.OutlineBlueA400,
                        fontStyle: TextFormFieldFontStyle
                            .SourceSansProSemiBold16Gray900a2,
                        alignment: Alignment.centerLeft,
                        suffix: Padding(
                          padding: getPadding(left: 20, right: 20),
                          child: Image.asset(
                            ImageConstant.call,
                            color: Color(0xFF858C94),
                          ),
                        ),
                        suffixConstraints: BoxConstraints(
                            maxWidth: getHorizontalSize(64),
                            maxHeight: getVerticalSize(24)),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: getPadding(
                          left: 44,
                          top: 24,
                          right: 44,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "Gender",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                color: isDark
                                    ? Colors.white
                                    : ColorConstant.bluegray800A2,
                                fontSize: getFontSize(
                                  16,
                                ),
                                fontFamily: 'Source Sans Pro',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                bottom: 5,
                              ),
                              child: Text(
                                "*",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: ColorConstant.redA700A2,
                                  fontSize: getFontSize(
                                    14,
                                  ),
                                  fontFamily: 'Source Sans Pro',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: getVerticalSize(65),
                      margin: getMargin(left: 10, right: 10),
                      decoration: BoxDecoration(
                          boxShadow:
                              isDark ? customDarkBoxShadow : customBoxShadow),
                      child: CustomDropDown(
                        isDark: isDark,
                        width: size.width,
                        focusNode: FocusNode(),
                        hintText: "Gender",
                        value: dropDownVal,
                        icon: Image.asset(
                          ImageConstant.dropDown,
                          height: getVerticalSize(
                            7.00,
                          ),
                          width: getHorizontalSize(
                            15.00,
                          ),
                        ),
                        items: dropdownItemList,
                        fontStyle: DropDownFontStyle.PlusJakartaSansMedium14,
                        onChanged: (value) {
                          setState(() {
                            dropDownVal = value;
                          });
                        },
                        margin: getMargin(
                          left: 10,
                          right: 10,
                        ),
                        alignment: Alignment.center,
                        prefixConstraints: BoxConstraints(
                          minWidth: getSize(
                            20.00,
                          ),
                          minHeight: getSize(
                            20.00,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      margin: getMargin(
                        left: 24,
                        top: 24,
                        right: 24,
                      ),
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    2.00,
                                  ),
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: getPadding(
                                        left: 24,
                                        top: 1,
                                        right: 24,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 3,
                                            ),
                                            child: Text(
                                              "Write Your Problem",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                color: isDark
                                                    ? Colors.white
                                                    : ColorConstant.gray900A2,
                                                fontSize: getFontSize(
                                                  16,
                                                ),
                                                fontFamily: 'Source Sans Pro',
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              bottom: 5,
                                            ),
                                            child: Text(
                                              "*",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                color: ColorConstant.redA700A2,
                                                fontSize: getFontSize(
                                                  14,
                                                ),
                                                fontFamily: 'Source Sans Pro',
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                        boxShadow: isDark
                                            ? customDarkBoxShadow
                                            : customBoxShadow),
                                    child: CustomTextFormField(
                                      isDark: isDark,
                                      width: 380,
                                      focusNode: FocusNode(),
                                      hintText:
                                          "Tell doctor about your problem",
                                      margin: getMargin(
                                        top: 11,
                                      ),
                                      shape: TextFormFieldShape.RoundedBorder16,
                                      padding:
                                          TextFormFieldPadding.PaddingAll18,
                                      fontStyle: TextFormFieldFontStyle
                                          .SourceSansProSemiBold16Gray900a2,
                                      textInputAction: TextInputAction.done,
                                      alignment: Alignment.centerLeft,
                                      suffix: Container(
                                        margin: getMargin(
                                          left: 30,
                                          top: 30,
                                          right: 14,
                                          bottom: 6,
                                        ),
                                        child: CommonImageView(
                                          svgPath: ImageConstant.imgSearch,
                                        ),
                                      ),
                                      suffixConstraints: BoxConstraints(
                                        minWidth: getHorizontalSize(
                                          6.00,
                                        ),
                                        minHeight: getVerticalSize(
                                          6.00,
                                        ),
                                      ),
                                      maxLines: 3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            CustomButton(
              isDark: isDark,
              width: size.width,
              text: "Записаться",
              margin: getMargin(
                left: 20,
                top: 20,
                right: 20,
                bottom: 20,
              ),
              onTap: () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                var user = prefs.getString('user');
                print(user);
                _sendPostRequest();
                /*Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => LightAppointmentsStep4FilledScreen(
                            contactMethod: widget.contactMethod,
                          )),
                );*/
              },
              fontStyle: ButtonFontStyle.SourceSansProSemiBold18,
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> _sendPostRequest() async {
  try {
    final String apiUrl = 'https://dev.free-dharma.ru/doctors/appointments';

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));

    // Set headers
    request.headers['accept'] = '*/*';
    request.headers['accept-language'] =
        'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7,tg;q=0.6';
    request.headers['content-type'] =
        'multipart/form-data; boundary=----WebKitFormBoundaryCq98Ts7qHBWd6hIU';
    request.headers['cookie'] =
        '__stripe_mid=e0dd2a9b-f72f-4af1-bbd1-841ee84f95968f6cb0; __stripe_sid=dd04e465-6ac7-4f6e-ad58-4bdb8feb87f1b5230d; XSRF-TOKEN=eyJpdiI6IjBrTmFpWGdteDVRbFJtRWVzbFVDZ3c9PSIsInZhbHVlIjoiNDBRdmh1bDkrYk5iTU80djQ2WXBZazVYR3FTS1doRUlXWGZGdHhLYTRDQm5QQUx1MVZHOXdaL3JGZmFhS2FnNWpqeGRobzNFSWp1aTJ2REZqaVpuZDhyVnVkeXZTREJ6R1ljaDN2YzMxT2VNVnp5R1kxcENWc256OTVWelRCNUwiLCJtYWMiOiJhYzI3YTIyNTVmMjU5MTI3MTQ5ODI5ZTBiYmMxYTYyYmY3ZmU0ODg4NDc4ZDllNzJmNWI4OWMxZThlMTkyMTAxIiwidGFnIjoiIn0%3D; laravel_session=eyJpdiI6Im9DbGdvQTJtU3pMU3I3bU5Gek1aZ3c9PSIsInZhbHVlIjoiS1J3TURVWUQrNWorVUdXZXZ1bmhCOEt1MWJUb3JVSG9uZmg0RjY1cFdMMVlCNVhDaUFYQ0V5SURmRXM3blpiazdwaWUvTzNsQ2Fxc1lub2NQWlBtTEc0K1J6WXNSdnBoWWtvdElDNmVKUTB1MzFleEpvejNNeVBYUE1Vd05hWkIiLCJtYWMiOiJhNGI3YzUxZmVmN2VhYjViYjY4MWZkYzc5NjI3YmI5YzgzNmY4MTEzZGQ5NzZiZmEyNWFiYTMxZmE4Y2M4OWEzIiwidGFnIjoiIn0%3D';
    request.headers['dnt'] = '1';
    request.headers['origin'] = 'https://dev.free-dharma.ru';
    request.headers['priority'] = 'u=1, i';
    request.headers['referer'] =
        'https://dev.free-dharma.ru/doctors/appointments/create';
    request.headers['sd234bwizgq5lpwxvzwa3'] = 'x2qd9c7m2Bd17pL3V8Ltd';
    request.headers['sec-ch-ua'] =
        '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"';
    request.headers['sec-ch-ua-mobile'] = '?0';
    request.headers['sec-ch-ua-platform'] = '"macOS"';
    request.headers['sec-fetch-dest'] = 'empty';
    request.headers['sec-fetch-mode'] = 'cors';
    request.headers['sec-fetch-site'] = 'same-origin';
    request.headers['sec-gpc'] = '1';
    request.headers['user-agent'] =
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
    request.headers['x-csrf-token'] =
        'Q2bMyRdfSjeMHO6yYbb1dBvd9axALLcnUEMswRI7';
    request.headers['x-requested-with'] = 'XMLHttpRequest';

    // Add form fields
    request.fields['_token'] = 'Q2bMyRdfSjeMHO6yYbb1dBvd9axALLcnUEMswRI7';
    request.fields['doctorRole'] = '1';
    request.fields['doctor_id'] = '3';
    request.fields['status'] = '1';
    request.fields['date'] = '2024-09-06';
    request.fields['service_id'] = '2';
    request.fields['patient_id'] = '2';
    request.fields['from_time'] = '03:00 PM';
    request.fields['to_time'] = ' 04:00 PM';
    request.fields['description'] = 'fdg';
    request.fields['payment_type'] = '1';
    request.fields['charge'] = '500';
    request.fields['add_fees'] = '';
    request.fields['payable_amount'] = '500';

    var stream = await request.send();

    print('Response status: ${stream.statusCode}');
    print('Response body: ${await stream.stream.bytesToString()}');
  } catch (e) {
    print('Error: $e');
  }
}

void __sendPostRequest() async {
  final String apiUrl = 'https://dev.free-dharma.ru/doctors/appointments';

  final response = await http.post(
    Uri.parse(apiUrl),
    headers: {
      'Content-Type':
          'multipart/form-data; boundary=----WebKitFormBoundaryCq98Ts7qHBWd6hIU',
      // ... other headers ...
    },
    body: _createFormData(),
  );

  if (response.statusCode == 200) {
    print('Success!');
    print('Response: ${response.body}');
  } else {
    print('Failed with status code: ${response.statusCode}');
    print('Response: ${response.body}');
  }
}

Map<String, dynamic> _createFormData() {
  return {
    '_token': 'Q2bMyRdfSjeMHO6yYbb1dBvd9axALLcnUEMswRI7',
    'doctorRole': '1',
    'doctor_id': '3',
    'status': '1',
    'date': '2024-09-05',
    'service_id': '2',
    'status': '1',
    'patient_id': '2',
    'from_time': '09:00 PM',
    'to_time': ' 11:00 PM',
    'description': 'fdg',
    'payment_type': '1',
    'charge': '500',
    'add_fees': '',
    'payable_amount': '500'
  };
}
