import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:doctorq/core/utils/pub.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/*Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Permission.camera.request();
  await Permission.microphone.request(); // if you need microphone permission
  await Permission.storage.request();
  if (Platform.isAndroid) {
    await AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
  }
  runApp(MaterialApp(home: new SerView()));
}*/

class SerView extends StatefulWidget {
  final bool? doctor;
  String user;
  String doctorId;
  //SerView(bool doctor);

  SerView({required this.doctorId, required this.user, this.doctor});
  @override
  _MyAppState createState() => new _MyAppState();
}

class _MyAppState extends State<SerView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;
  InAppWebViewSettings options = InAppWebViewSettings(
      mediaPlaybackRequiresUserGesture: false,
      useHybridComposition: true,
      allowsInlineMediaPlayback: false,
      javaScriptCanOpenWindowsAutomatically: false,
      transparentBackground: true,
      allowBackgroundAudioPlaying: true);
  /* InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: true,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));
*/
  late PullToRefreshController pullToRefreshController;
  String url = "";
  double progress = 0;
  final urlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    print("initied ser_view");
    print(widget
        .doctor); /*
    WidgetsFlutterBinding.ensureInitialized();

    Permission.camera.request();
    Permission.microphone.request(); // if you need microphone permission
    Permission.storage.request();
    if (Platform.isAndroid) {
      AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
    }*/
    /*Future.delayed(Duration(seconds: 15), () {
      print("tik");

      webViewController?.evaluateJavascript(source: "location.reload();");
    });*/
    pullToRefreshController = PullToRefreshController(
      options: PullToRefreshOptions(
        color: Colors.blue,
      ),
      onRefresh: () async {
        if (Platform.isAndroid) {
          webViewController?.reload();
        } else if (Platform.isIOS) {
          webViewController?.loadUrl(
              urlRequest: URLRequest(url: await webViewController?.getUrl()));
        }
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('doctor');
    print(widget.doctor == true);
    print(widget.doctorId);
    print("https: //webrtc20.onrender.com/tutorials/hello-world.html?id=" +
        jsonDecode(widget.user)['user_id']);
    //Permission.camera.request();
    //Permission.microphone.request(); // if you need microphone permission
    //Permission.storage.request();
    if (Platform.isAndroid) {
      AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
    }
    return Scaffold(
        /*
        floatingActionButton:
            FloatingActionButton(onPressed: () {}, child: Text("stop")),*/
        // appBar: AppBar(title: Text("Official InAppWebView website")),
        body: SafeArea(
            child: Column(children: <Widget>[
      Expanded(
        child: Stack(
          children: [
            InAppWebView(
              // headlessWebView:true,
              key: webViewKey,
              initialUrlRequest: URLRequest(
                  //   url: WebUri("https://google.com")),
                  url: WebUri(widget.doctor == true
                      ? "https://webrtc20.onrender.com/tutorials/hello-world.html?id=500"
                      // jsonDecode(widget.user)['user_id']
                      : "https://webrtc20.onrender.com/tutorials/dial.html?id=500")), // widget.doctorId)),
              initialSettings: options,
              pullToRefreshController: pullToRefreshController,
              onWebViewCreated: (controller) {
                webViewController = controller;
              },
              onLoadStart: (controller, url) {
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              androidOnPermissionRequest:
                  (controller, origin, resources) async {
                return PermissionRequestResponse(
                    resources: resources,
                    action: PermissionRequestResponseAction.GRANT);
              },
              shouldOverrideUrlLoading: (controller, navigationAction) async {
                var uri = navigationAction.request.url!;

                return NavigationActionPolicy.ALLOW;
              },
              onLoadStop: (controller, url) async {
                pullToRefreshController.endRefreshing();
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              onLoadError: (controller, url, code, message) {
                pullToRefreshController.endRefreshing();
              },
              onProgressChanged: (controller, progress) {
                if (progress == 100) {
                  pullToRefreshController.endRefreshing();
                }
                setState(() {
                  print(progress);
                  this.progress = progress / 100;
                  urlController.text = this.url;
                });
              },
              onUpdateVisitedHistory: (controller, url, androidIsReload) {
                setState(() {
                  this.url = url.toString();
                  urlController.text = this.url;
                });
              },
              onConsoleMessage: (controller, consoleMessage) {
                print("console:");
                print(consoleMessage);
                if (consoleMessage.message == 'Session: ENDED') {
                  print("trying to pop");
                  Navigator.pop(context);
                } else {
                  print("not bye");
                }
              },
            ),
            progress < 1.0
                ? LinearProgressIndicator(value: progress)
                : Container(child: Text("loading")),
          ],
        ),
      ),
      ButtonBar(
        alignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            child: Icon(Icons.arrow_back),
            onPressed: () {
              webViewController?.goBack();
            },
          ),
          ElevatedButton(
            child: Icon(Icons.arrow_forward),
            onPressed: () {
              webViewController?.goForward();
            },
          ),
          ElevatedButton(
            child: Icon(Icons.refresh),
            onPressed: () {
              webViewController?.reload();
            },
          ),
        ],
      ),
    ])));
  }
}
