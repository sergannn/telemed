import 'package:flutter/material.dart';

class Constants{
 
  
  static String currency='\$';
  static Locale engLocal=Locale('en');
  static Locale arLocal=Locale('ar');
}