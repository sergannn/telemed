import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:pubnub/pubnub.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

String _inputText = '';
String _uname = '';
String _upass = '';
String? token;
String? user_id;
XFile? file_to_upload;
final String kApiDomain = 'https://fuck-laravel.onrender.com';

Future<bool> changeRole(role) async {
  print('changing role');
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('role', role);
  // Optionally, save the role based on the switch state

  var res = await prefs.getBool('role') ?? false;
  print(res);
  return res;
}

Future<bool> getRole() async {
  print('getting role');
  final prefs = await SharedPreferences.getInstance();

  var res = await prefs.getBool('role') ?? false;
  // Optionally, save the role based on the switch state
  print(res);
  return res;
}

Future<bool> getDoctors() async {
  var res;
  // Append the query string to the base URL
  var url = Uri.parse('$kApiDomain/api/users');

  final response = await http.get(
    url,
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
      //   'Authorization': 'Bearer $api_token',
      'Accept': 'application/json'
    },
  );
  // Handle the response
  if (response.statusCode == 200) {
    print('got doctors successful');
    var jsonResponse = jsonDecode(response.body);

    print(jsonResponse);
    res = jsonResponse;
  } else {
    res = '';
  }
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.setString('doctors', response.body);
}

Future<String> getTokenFromPrefs() async {
  //logOut();
  final prefs = await SharedPreferences.getInstance();
  /*
  token = prefs.getString('token');
  user_id = prefs.getString("user_id");
  print('Token from SharedPreferences: $token, $user_id');*/
  // You can now use the token in your API calls
  //if( prefs.getString("user")== )
  return prefs.getString("user") ?? '{"user_id":"-1"}';
  return user_id ?? '-1';
}

Future<bool> authUser(String username, String password) async {
  print(username);
  print(password);
  // var api_token = "2|2KpxCqTtgvizQlPdpyw1LYPiHGVGHcswzO3GtZDx05cee19b";
  var queryParams = {
    'email': username,
    'password': password,
  };
  // Convert the query parameters to a query string
  var queryString = Uri(queryParameters: queryParams).query;

  // Append the query string to the base URL
  var url = Uri.parse('$kApiDomain/api/login?$queryString');

  final response = await http.get(
    url,
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
      //   'Authorization': 'Bearer $api_token',
      'Accept': 'application/json'
    },
  );
  // Handle the response
  if (response.statusCode == 200) {
    print('Authentication successful');
    var jsonResponse = jsonDecode(response.body);

    // Modify the jsonResponse here if needed
    // For example, ensuring user_id is a string
    // Note: This step assumes user_id exists and is not already a string
    if (jsonResponse['user_id'] is int) {
      // Check if user_id is an integer
      jsonResponse['user_id'] =
          jsonResponse['user_id'].toString(); // Convert it to string
    }
    String modifiedResponseBody = jsonEncode(jsonResponse);
    /*var token = jsonResponse['access_token'];
    var user_id = jsonResponse['user_id'];
    var username = jsonResponse['username'];
    var photo = jsonResponse['photo'];
*/
    print(token);
    print(modifiedResponseBody);

    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('user', modifiedResponseBody);
    /*
    prefs.setString('token', token.toString());
    prefs.setString('user_id', user_id.toString());
    prefs.setString('username', username.toString());
    prefs.setString('photo', photo.toString());*/
    return true;
    // Process the response
  } else {
    print('Failed to authenticate');
    return false;
    //Toast('failed to auth');
    // Handle the error
  }
}

Future<String?> logOut() async {
  final prefs = await SharedPreferences.getInstance();
  prefs.remove('user');
  /*prefs.remove('token');
  prefs.remove("user_id");

  prefs.remove("username");
  prefs.remove("photo");
*/
  //Toast('logged out');
  return 'logged out';

  // You can now use the token in your API calls
}

initPub() {
  late PubNub pubnub;
//  late CameraController controller;
  var count = 0;
  var channel;
  var last_msg = '';
  // Create PubNub instance with default keyset.
  return PubNub(
      defaultKeyset: Keyset(
          subscribeKey: 'sub-c-f5659372-2568-4f19-bc2a-be6a5dbe4d65',
          publishKey: 'pub-c-9d2c07d1-d4b6-403b-b0c3-def8a944666e',
          userId: UserId('Demo Keyset')));
}
