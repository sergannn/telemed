class DoctorsModel {
  String img, name, specialization, shortSpecialization;
  DoctorsModel(
      {required this.img,
      required this.name,
      required this.specialization,
      required this.shortSpecialization}) {
    print("something with model");
  }
}
