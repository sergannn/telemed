import '../models/chat_model.dart';

List<ChatModel> chatList = [
  ChatModel(
      msg:
          'Hello Adam, I am Dr. Eleanor Pena.I will help to solve your disease complaints.',
      isMine: false),
  ChatModel(
      msg: 'First, can you tell me about your illness so far', isMine: false)
];
