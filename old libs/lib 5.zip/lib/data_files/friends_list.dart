
import 'package:doctorq/theme/image_constant.dart';
import 'package:doctorq/models/friends_model.dart';

List<FriendsModel> friendsList=[
  FriendsModel(name: 'Darrell Steward', img: ImageConstant.friend1,),
  FriendsModel(name: 'Robert Fox', img: ImageConstant.friend2,),
  FriendsModel(name: 'Wade Warren', img: ImageConstant.friend3,),
  FriendsModel(name: 'Kristin Watson', img: ImageConstant.friend4,),
  FriendsModel(name: 'Marvin McKinney', img: ImageConstant.friend5,),
  FriendsModel(name: 'Wade Warren', img: ImageConstant.friend6,),
];