class DoctorsModel {
  String img, name, specialization, shortSpecialization, id;
  DoctorsModel(
      {required this.img,
      required this.name,
      required this.specialization,
      required this.shortSpecialization,
      required this.id});
}
